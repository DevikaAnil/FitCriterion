package com.example.devika.studentdatabase;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

/**
 * Created by Devika on 3/21/2017.
 */

public class viewall extends Activity {
    dbmscontrol controller;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewall);
        textView=(TextView)findViewById(R.id.textview);
        controller=new dbmscontrol(this,"",null,1);

    }

    public void onbutton5click(View view) {
        if (view.getId()==R.id.bt5){
            controller.view(textView);

        }
    }
}
