package com.example.devika.studentdatabase;
import java.util.ArrayList;
import android.app.Activity;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View.OnClickListener;
import android.app.ListActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.AdapterView;
import android.widget.ListView;

import static android.support.constraint.R.id.parent;


/**
 * Created by Devika on 3/21/2017.
 */

public class listdel extends Activity {
    dbmscontrol controller;
    ListView listView;
    ArrayList<String>thelist = new ArrayList<>();
    /*public void saveArrayList(){
        int i;
        SharedPreferences sharedprefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor=sharedprefs.edit();
        for(i=0;i<thelist.size();i++){
            editor.remove(thelist.get(i));
            editor.putString(thelist.get(i),thelist.get(i+1));


        }

    }*/
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listdel);
        listView = (ListView) findViewById(R.id.list);
        controller = new dbmscontrol(this, "", null, 1);


        Cursor data = controller.getListContents();
        while (data.moveToNext()) {
            thelist.add(data.getString(0));

        }
        final ListAdapter listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, thelist);
        listView.setAdapter(listAdapter);
        //final ListAdapter listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, thelist);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?>parent,View view,int position,long id) {

                try {
                    String name = thelist.get(position);
                    thelist.remove(position);
                    controller.delstudent(name);
                    //listView.setAdapter();
                    listAdapter.notify();
                    listView.setAdapter(listAdapter);
                }catch(Exception ex){
                    Log.i("Check2", ex.getMessage());
                }
                //controller.saveArrayList();
                //thelist.notifyAll();

            }
        });

        }

}





