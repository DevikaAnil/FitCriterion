package com.example.devika.studentdatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onbutton1click(View v){
        if (v.getId()==R.id.bt1){
            Intent i= new Intent(MainActivity.this,details.class);
            startActivity(i);
        }

    }
    public void onbutton2click(View v){
        if (v.getId()==R.id.bt2){
            Intent i= new Intent(MainActivity.this,viewall.class);
            startActivity(i);
        }

    }
    public void onbutton3click(View v){
        if (v.getId()==R.id.bt3){
            Intent i= new Intent(MainActivity.this,listdel.class);
            startActivity(i);
        }

    }
}
