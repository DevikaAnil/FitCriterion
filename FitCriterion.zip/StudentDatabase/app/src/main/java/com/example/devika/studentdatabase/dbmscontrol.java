package com.example.devika.studentdatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TextView;

/**
 * Created by Devika on 3/21/2017.
 */

public class dbmscontrol extends SQLiteOpenHelper {
    TextView textView;

    public dbmscontrol(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "JOBSEEKER.db", factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE JOBSEEKER(NAME TEXT, AGE TEXT, BRANCH TEXT ,SKILLS TEXT, GPA TEXT);");

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS JOBSEEKER;");
        onCreate(db);
    }

    public void addstudent(String name, String age, String branch , String skills, String gpa){
        ContentValues contentvalues = new ContentValues();
        contentvalues.put("NAME",name);
        contentvalues.put("AGE",age);
        contentvalues.put("BRANCH",branch);
        contentvalues.put("SKILLS",skills);
        contentvalues.put("GPA",gpa);



        this.getWritableDatabase().insertOrThrow("JOBSEEKER","",contentvalues);
    }



    public void delstudent(String name){
        this.getWritableDatabase().delete("JOBSEEKER","NAME='"+name+"'",null);
    }
    public void view(TextView textView){
        Cursor cursor= this.getReadableDatabase().rawQuery("SELECT * FROM JOBSEEKER", null);
        textView.setText(" ");
        while(cursor.moveToNext()){
            textView.append("name:     "+" "+cursor.getString(0)+"\n"+"age     "+" "+cursor.getString(1)+"\n"+ "branch:     "+" "+cursor.getString(2)+"\n"+ "skill     "+" "+cursor.getString(3)+"\n" + "gpa    "+" "+cursor.getString(4)+"\n\n");

        }
    }
    public Cursor getListContents(){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor data=db.rawQuery("SELECT * FROM JOBSEEKER",null);
        return data;

    }



}

