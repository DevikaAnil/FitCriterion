package com.example.devika.studentdatabase;
import java.util.Arrays;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Devika on 3/21/2017.
 */

public class details extends Activity {

    dbmscontrol controller;
    EditText name,age,branch,skills,gpa,preexp;
    TextView textView;
    int score=0;
    String[][] answers = new String[][]{{"BE CSE","BE ISE", "ME CSE", "ME ISE "},{"algorithms","datastructures","html","css","php","teamwork","leadership","volunteer work"},{"8.0"},{"yes","no"}};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details);

        name=(EditText)findViewById(R.id.name);
        age=(EditText)findViewById(R.id.age);
        branch=(EditText)findViewById(R.id.branch);
        skills=(EditText)findViewById(R.id.skills);
        gpa=(EditText)findViewById(R.id.gpa);

        textView=(TextView)findViewById(R.id.TEXTVIEW);
        controller=new dbmscontrol(this,"",null,1);



    }

    public void ONBUTTON4CLICK(View view) {
        if (view.getId()==R.id.bt4){
            controller.addstudent(name.getText().toString(),age.getText().toString(), branch.getText().toString(),skills.getText().toString(),gpa.getText().toString());


            }
        }
    public void ONBUTTON6CLICK(View view){
        name=(EditText)findViewById(R.id.name);
        age=(EditText)findViewById(R.id.age);
        branch=(EditText)findViewById(R.id.branch);
        skills=(EditText)findViewById(R.id.skills);
        gpa=(EditText)findViewById(R.id.gpa);

        textView=(TextView)findViewById(R.id.TEXTVIEW);
        controller=new dbmscontrol(this,"",null,1);
        if (view.getId()==R.id.bt6){

            for(int i=0; i<answers[0].length;i++){
                if(branch.getText().toString().equals(answers[0][i])){
                    score=score+1;
                    break;
            }
        }
            String[] s=skills.getText().toString().split(",");
            for(int i=0;i<answers[1].length;i++){
                for(int j=0;j<s.length;j++){
                    if(answers[1][i].equals(s[j])){
                        score=score+1;
                }
            }}
            Float a=Float.parseFloat(gpa.getText().toString());
            Float b=Float.parseFloat(answers[2][0]);

            if(a>=b){
                score=score+1;
        }
            textView.setText(""+score);






        }
    }


    }

